package com.androidlec.icontact;

public class STATICDATA {
    public static int FTPUPLOAD = 0;
    public static int UPLOADSTATUS = 0;
    public static String FILENAME = "";
    public static int LOGINSTATUS = 0;
    public static String USEREMAIL = "";
    public static String USERNAME = "";
    public static int USERSTATUS = 0;
    public static int LOGINCOUNT = 0;
}
